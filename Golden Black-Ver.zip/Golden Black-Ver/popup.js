// popup.js
const SUPABASE_URL      = "https://kpqzmbukgrllrwexdveo.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtwcXptYnVrZ3JsbHJ3ZXhkdmVvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDIzMTUyNDgsImV4cCI6MjA1Nzg5MTI0OH0.J5N2U3EDZZ5tuX0esIcxzS62yLXA9NsvW8JTmXu7wXI";
const supabase          = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// DOM refs
const loginContainer = document.getElementById("login-container");
const roomContainer  = document.getElementById("room-container");
const loginUserIn    = document.getElementById("login-username");
const loginPassIn    = document.getElementById("login-password");
const loginBtn       = document.getElementById("login-btn");
const loginError     = document.getElementById("login-error");
const roomList       = document.getElementById("room-list");

// Room definitions
const rooms = [
  { name: "Organ",    icon: "icons/Organ.png"    },
  { name: "Piano",    icon: "icons/Piano.png"    },
  { name: "Bassdrum", icon: "icons/Bassdrum.png" },
  { name: "Harp",     icon: "icons/Harp.png"     },
  { name: "Violin",   icon: "icons/Violin.png"   },
  { name: "Flute",    icon: "icons/Flute.png"    }
];

// Helpers to show/hide
function showLogin() {
  loginContainer.classList.remove("hidden");
  roomContainer.classList.add("hidden");
}
function showRooms() {
  loginContainer.classList.add("hidden");
  roomContainer.classList.remove("hidden");
}

// Render the room buttons
function renderRooms() {
  roomList.innerHTML = "";
  rooms.forEach(r => {
    const btn = document.createElement("button");
    btn.classList.add("room-btn");
    btn.onclick = () => {
      localStorage.setItem("loginUsername", loginUserIn.value.trim().toLowerCase());
      localStorage.setItem("selectedRoom", r.name);
      window.location.href = "chat.html";
    };
    const img = document.createElement("img");
    img.src = r.icon; img.alt = r.name; img.classList.add("room-icon");
    btn.appendChild(img);
    roomList.appendChild(btn);
  });
}

// Perform login
loginBtn.addEventListener("click", async () => {
  loginError.textContent = "";
  const username = loginUserIn.value.trim().toLowerCase();
  const password = loginPassIn.value;
  if (!username || !password) {
    loginError.textContent = "Please enter both username and password.";
    return;
  }

  let { data, error, status } = await supabase
    .from("users")
    .select("password, active, session_token, active_until")
    .eq("username", username)
    .single();

  if (status === 406 || status === 404 || !data) {
    loginError.textContent = "Account not registered.";
    return;
  }
  if (error) {
    loginError.textContent = "Unexpected error. Try again.";
    return;
  }
  if (!data.active) {
    loginError.textContent = "Account is disabled.";
    return;
  }
  if (data.password !== password) {
    loginError.textContent = "Incorrect password.";
    return;
  }
  // Optionally enforce single session here...

  // Success → show rooms
  renderRooms();
  showRooms();
});

// Always start at login
showLogin();
